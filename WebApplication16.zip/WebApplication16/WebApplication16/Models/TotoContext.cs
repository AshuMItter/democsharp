﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace WebApplication16.Models
{
    public class TotoContext : DbContext
    {
        public TotoContext(DbContextOptions options):base(options)
        {
         
            
        }
        public TotoContext()
        {

        }
       

        public DbSet<ToDoItems> itemsToDo { get; set; }
    }
}
