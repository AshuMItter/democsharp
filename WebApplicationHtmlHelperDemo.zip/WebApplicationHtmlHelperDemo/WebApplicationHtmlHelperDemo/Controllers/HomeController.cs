﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebApplicationHtmlHelperDemo.Models;
using System.Linq;

namespace WebApplicationHtmlHelperDemo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public bool ValidateUserName(string username)
        {
            List<string> uSname = new List<string>()
            {
                "LeoNeo",
                "Joe",
                "Prathmesh",
                "Reeta"
            };

            return false;


        }
        public IActionResult HandelePost(SignUpDetails details)
        {
            var res = new SignUpDetails()
            {
                FirstName = "Joe",
                LastName = "Patil",
                Age = 30,
                Country = "India",
                Gender = "Male",
                IsAdhaarCardNumberGenerated = true
            };

            if (ModelState.IsValid)
            {

            }
            
            return View(res);
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
