﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationHtmlHelperDemo.Models
{
    public class SignUpDetails
    {
        [StringLength(5)]
        public string FirstName { get; set; }

        public string LastName { get; set; }

        [Range(1,100,ErrorMessage ="Please check the entered age !!")]
        public int Age { get; set; }

        public string Country { get; set; }

        [Compare("Age",ErrorMessage ="It does not match")]
        public int NewAge { get; set; }
        
        [EmailAddress]
        public string Email { get; set; }
        public string Gender { get; set; }

        /// <summary>
        /// Remote Validation
        /// </summary>
        [Remote(action: "ValidateUserName", controller:"Home", ErrorMessage ="This username is not available")]
        public string UserName { get; set; }

        public bool IsAdhaarCardNumberGenerated { get; set; }
    }
}
