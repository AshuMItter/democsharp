﻿using System;
using System.Text;
using DemoOne.Concepts;
using DemoOne.Demos;
using System.Net;
using System.Threading;
using System.Diagnostics;
using System.Reflection;
namespace DemoOne
{
    
    class Program
    {

       
        public static int MethodForArgument(string name)
        {
            Console.WriteLine(name);
            return 34;
        }
        
        public static void Func3()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Funtion3 executing");
                Thread.Sleep(4000);
            }
            
        }
        
        public static void Function1()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Executing Funtion1 :"+i);
                //wait for some time
                Thread.Sleep(4000);
            }
           
        }
        public static void Function2()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Executing Funtion2 :" + i);
                Thread.Sleep(4000);
            }
            // wait for some time
            

        }
        
        static void Main(string[] args)
        {
            // arrays having null values
            int?[] array2 = new int?[5] { null, 45, 56, 67, 45, };

            //Console.WriteLine(array2[1]);
            foreach (var item in array2)
            {
                Console.WriteLine(item);
            }

            //SerializationDemo obj = new SerializationDemo();
            //obj.Freeze();
            //obj.DeSerializeTheFreeze();

            //int[] demoArray = new int[5];
            //demoArray[0] = 34; // putting the value in the array.
            //Console.WriteLine(demoArray[0]);


            //FileHandlingCsharp objFile = new FileHandlingCsharp();
            //objFile.DemoFileHAndling();





            //SerializationDemo dem0 = new SerializationDemo();
            //dem0.DeSerializeTheFreeze();
            //SerializationDemo sd = new SerializationDemo();
            //sd.PerformSerialization();
            //sd.PerformDeseriaalization();
            //AttrDemo demo = new AttrDemo();
            //demo.DemoWalk();

            //Thread obj3 = new Thread(Func3);
            ////making it a background thread.
            //obj3.Start();
            //obj3.IsBackground = true;

            // obj3.Start();
            // Console.WriteLine("the main app has quit");

            //Thread obj1 = new Thread(Function1);
            //Thread obj2 = new Thread(Function2);
            //Thread obj3 = new Thread(Func3);
            //obj1.Start();
            //obj2.Start();
            //obj3.Start();






        }

      
       
    }
        

    }
   
           
        
    

