﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
namespace DemoOne.Demos
{

    
    [Obsolete("It is old",true)]
    class AttrDemo
    {
       public void DemoWalk()
        {
            Console.WriteLine("Hello world");
        }
    }
}
