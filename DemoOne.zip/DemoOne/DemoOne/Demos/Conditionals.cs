﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoOne.Demos
{
    class Conditionals
    {
        public void setUpConditions()
        {

            int num = 90;
            switch (num)
            {
                case 5:
                    Console.WriteLine("Hello World");
                    break;
                case 90:
                    Console.WriteLine("Hi");
                    break;
                default:
                    Console.WriteLine("Default");
                    break;
            }

            if (true)
            {

            }
            else if (false)
            {

            }
            else if (true)
            {

            }
            else if (true)
            {

            }
            else
            {

            }

        }
    }
}
