﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoOne.Demos
{
    class PClass
    {
        const int a = 90;

        readonly int v = 90;
        public PClass()
        {
            v = 67;

        }
        public void Demo()
        {
           
        }
    }
    partial class One
    {
        public void Add()
        {

        }
    }
    partial class One
    {
        public void Subtract()
        {

        }
    }
    partial class One
    {
        public void Divide() { }
    }
}
