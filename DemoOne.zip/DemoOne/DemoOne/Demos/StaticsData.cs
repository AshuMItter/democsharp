﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoOne.Demos
{
   static class StaticsData
    {
        

        public static int Age { get; set; }
        public static string Name { get; set; }

        public static void MyStaticFunation()
        {

        }
        public static int Location { get; set; }
        
    }
}
