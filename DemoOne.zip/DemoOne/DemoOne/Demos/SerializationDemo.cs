﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
namespace DemoOne.Demos
{
    class SerializationDemo
    {



         public void Freeze()
         {
            Data myProduct = new Data() { ID = 2345, BrandName = "MSI", Price = 76000, ProductDescription = "16GB RAM I7 1Tb Harddisk", ProductName = "MSI 17B4" };
            FileStream fs = new FileStream(@"C:\Users\ANKIT\Desktop\PhD\Product.bin", FileMode.Create, FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs, myProduct);
            fs.Flush();
            fs.Close();
            fs.Dispose();

        }

        public void DeSerializeTheFreeze()
        {
            FileStream fs = new FileStream(@"C:\Users\ANKIT\Desktop\PhD\Product.bin", FileMode.Open, FileAccess.Read);
            BinaryFormatter bf = new BinaryFormatter();
            Data myData =(Data)bf.Deserialize(fs);


            Console.WriteLine(myData.BrandName);
            Console.WriteLine(myData.ID);
            Console.WriteLine(myData.Price);
            Console.WriteLine(myData.ProductDescription);
            Console.WriteLine(myData.ProductName);

            fs.Flush();
            fs.Close();
            fs.Dispose();
        }










        public void PerformSerialization() {
            Student student = new Student() { Age = 60, Name = "Reetu" };

            FileStream fs = new FileStream(@"C:\Users\ANKIT\Desktop\PhD\StudentFrozenState.bin",FileMode.OpenOrCreate,FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();

          
            bf.Serialize(fs, student);
            fs.Flush();
            fs.Close();
            fs.Dispose();
           
        }
        public void PerformDeseriaalization()
        {
            FileStream fs = new FileStream(@"C:\Users\ANKIT\Desktop\PhD\StudentFrozenState.bin", FileMode.Open, FileAccess.Read);
            BinaryFormatter bf = new BinaryFormatter();
            Student student = (Student)  bf.Deserialize(fs);

            Console.WriteLine(student.Age+" "+student.Name);
            fs.Flush();
            fs.Close();
            fs.Dispose();
        }
        
    }
    [Serializable]
    class Student
    {
        public int Age { get; set; }
        public string Name { get; set; }
    }
}
