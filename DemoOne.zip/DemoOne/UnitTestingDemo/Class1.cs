﻿using System;
using NUnit.Framework;
using System.Collections.Generic;
namespace UnitTestingDemo
{

    class Test
    {
        [TestCase(12, 3, 4)]
        [TestCase(12, 2, 6)]
        [TestCase(12, 4, 3)]
        public void DivideTest(int n, int d, int q)
        {
            Assert.AreEqual(q, n / d);
        }
        public int Add(int num1,int num2)
        {
            return num1 + num2;
        }
        
        [Test]
        public void TestCase()
        {
           // Test Obj = new Test();
            Assert.That(20,Is.EqualTo(Obj.Add(10,10)));
            
        }
        Test Obj;
        [SetUp]
        public void SetUp()
        {
            Obj = new Test();
        }
        [Test]
        public void TestCase2()
        {
            CollectionAssert.DoesNotContain(new List<int>() { 2, 3, 5 },new List<int>() { 2, 3, 5 });
        }
    }
    public class Account
    {
        public decimal Balance { get; set; }
        public Account(decimal balance)
        {
            Balance = balance;
        }
        public void Withdraw(decimal amount)
        {

            if(Balance >= amount)
            {
                // logic flow one
                Balance -= amount;
            }
            else
            {
                //logic flow two
                throw new Exception("Insufficient funds");
            }
        }
        public void Deposit(decimal amount)
        {
            if(amount < 0)
            {
                //logic flow three
                throw new InvalidOperationException();
            }
            // logic flow four..
            Balance  = Balance+ amount;


        }
    }
}
