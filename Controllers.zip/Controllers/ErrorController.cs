﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication27.Controllers
{
    public class ErrorController : Controller
    {
        public IActionResult Info()
        {
            return View();
        }
    }
}
