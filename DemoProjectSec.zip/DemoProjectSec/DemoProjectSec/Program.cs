﻿using System;

namespace DemoProjectSec
{
    class Program
    {
        static void Main(string[] args)
        {
            DataBaseTalk dbt = new DataBaseTalk();
            Data obj = new Data() { Location = "Pune", Name = "Leo", ProductID = 34 };

            dbt.DeleteRow(obj);

            Console.WriteLine(dbt.ToString());
        }
    }
    public class Data
    {
        public int ProductID { get; set; }
        public string Name { get; set; }

        public string Location { get; set; }
    }
    public class DataBaseTalk
    {
        public void FetchData(Data data)
        {
           
        }
        public void DeleteRow(Data data)
        {

        }
        public void UpdateRow(Data data)
        {

        }
        public void InsertData(Data data)
        {

        }
    }
}
