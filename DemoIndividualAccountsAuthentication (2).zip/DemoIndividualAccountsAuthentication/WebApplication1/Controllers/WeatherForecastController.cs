﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("employee")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet]      
        public IActionResult Get()
        {


            var rng = new Random();
          var res =  Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();

            if(res.Length  > 0)
            {
                return Ok(res);
            }
            else
            {
                return BadRequest();
            }
        }

        [Route("name")] //domainname/controllername/name
       public string GetName()
        {
            return "";
        }

        [Route("data")] //domaninname/controllernanem/data
        public Data GetData()
        {
            return new Data()
            {
                Age = 34,
                Name = "Ashu"

            };
        }
        [HttpPost]
       [Route("postman")]
        public IActionResult Post([FromBody] Data data)
        {
            return Ok(data);
        }
        [HttpPut]
        [Route("putman")]
        public IActionResult Put(int id)
        {
            return Ok(id);
        }
        [HttpDelete]
        [Route("deleteman")]
        public IActionResult Delete(int id)
        {
            return Ok(id);
        }
        [Route("one/{id}")] ////domainname/controllername/one/1
        public IActionResult MyCutomizedMethod(int id)
        {
            return Ok(id);
        }

        [Route("two")] //domainname/controllername/two?id=1
        public string DemoMyMethod(int id,string name)
        {
            return id + name;
        }


    }
    public class Data
    {
        public int Age { get; set; }
        public string Name { get; set; }
    }
}
