﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            MockDependencyObjet mockObject = new MockDependencyObjet();
            DepedencyObject reaObject = new DepedencyObject();
            ProductionObject obj = new ProductionObject(mockObject);

            obj.TightlyCoupledFunction();
        }
    }
    public interface IDependecy
    {
        string DependetMethod();
    }

    public class MockDependencyObjet : IDependecy
    {
        public string DependetMethod()
        {
            return "I am from Mock object";
            // dome logic
        }
    }

    public class DepedencyObject : IDependecy
    {
        public string DependetMethod()
        {
            throw new Exception();
          //  return "I am from Dependecy object or Real Production Code";
        }
    }

    public class ProductionObject
    {

        IDependecy reference;
        public ProductionObject(IDependecy dependency)
        {
            reference = dependency;
        }

        public int TightlyCoupledFunction()
        {


            Console.WriteLine(reference.DependetMethod());
            // further logic
            return 45;
        }
    }

}
