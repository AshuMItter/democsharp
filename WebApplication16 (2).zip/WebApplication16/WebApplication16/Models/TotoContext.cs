﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace WebApplication16.Models
{
    // step -2 - deriving the TotoContext from DbContext
    public class TotoContext : DbContext
    {
        // step - 3 - passing DBContextOptions options to base
        public TotoContext(DbContextOptions options):base(options)
        {
         
            
        }
        // step- 4 parameter less constructor
        public TotoContext()
        {

        }
       
        //-step 5 - adding Entitiess - Model - ToDoItems
        public DbSet<ToDoItems> itemsToDo { get; set; }

        //step -6 - add connection string in appsettings.json -> appsenttings.Development.json

        // for step seventh go to Startup.cs class
    }
}
