﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.Models;

namespace WebApplication16.Controllers
{
    public class HomeController : Controller
    {
        
        private readonly ILogger<HomeController> _logger;
        
        public HomeController(ILogger<HomeController> logger)
        {

           
            _logger = logger;
        }

        public IActionResult Index()
        {
            List<int> values = new List<int>();
            values.Add(34);
            values.Add(35);
            values.Add(36);
            return View();
        }



        public IActionResult MyView()
        {
            List<ToDoItems> items = new List<ToDoItems>();
            items.Add(new ToDoItems() { Id = 1, IsComplete = true, Name = "Leo" });
            items.Add(new ToDoItems() { Id = 2, IsComplete = false, Name = "Neo" });
            items.Add(new ToDoItems() { Id = 3, IsComplete = false, Name = "Raman" });
            items.Add(new ToDoItems() { Id = 4, IsComplete = true, Name = "Stagny" });


            ToDoItems item = new ToDoItems();
            item.Name = "Leo";
            item.Id = 34;
            item.IsComplete = false;

            return View(item);
        }

        public void Demo()
        {
            RedirectToAction("Privacy");
        }

        public IActionResult CreateData(ToDoItems items)
        {
           
            return View();
        }

        public IActionResult Update()
        {
            return View();
        }
        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Create()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
