﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StonglyTypedModelDemo.Models;
namespace StonglyTypedModelDemo.Controllers
{
    public class NewOneController : Controller
    {
        public IActionResult Index()
        {
            List<Person> person = new List<Person>()
            {
                new Person(){ PersonID=1, Name="Joe"},
                new Person(){ PersonID=2, Name="Neo"},
                new Person(){ PersonID=3, Name="Tracy"},
                new Person(){ PersonID=4, Name="Cigi"},
            };
            
                return View(person);
        }
    }
}
