﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StonglyTypedModelDemo.Models;
namespace StonglyTypedModelDemo.Controllers
{
    public class NewOneController : Controller
    {
        public IActionResult Index()
        {
            List<Person> person = new List<Person>()
            {
                new Person(){ PersonID=1, Name="Joe", Designation="Manager", Location="Pune" },
                new Person(){ PersonID=2, Name="Neo", Designation="Asst Manager", Location="Ahmadnagar"},
                new Person(){ PersonID=3, Name="Tracy", Designation="SME", Location="Mumbai"},
                new Person(){ PersonID=4, Name="Cigi", Designation="Admin", Location="Nanded"},
            };


            ViewBag.ProjectName = "This Data is from ViewBag";

            ViewData["Name"] = "This data is from ViewData";

            ViewBag.Data = "Hello World";
            TempData["Name"] = "Joe";
                return View(person);
        }

        public IActionResult Privacy()
        {
            ViewBag.DataFromIndex = ViewBag.ProjectName;

            ViewBag.Data = TempData["Name"];
            return View();
        }
    }
}
