﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Hello World!");
                SqlInteraction sqlInteract = new SqlInteraction();
                sqlInteract.FetachData();

                DemoData data = new DemoData() { Age = 34, LocationP = "Russia", NameP = "Dot Net",ID=2 };

               // Console.WriteLine(sqlInteract.DeletData(data));

                Console.WriteLine(sqlInteract.UpdateData(data));


               // Console.WriteLine(sqlInteract.InsertData(data));
               // sqlInteract.RunProc();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {

            }
           // sqlInteract.RunProc();
           // sqlInteract.JoinQuery();
        }
       
    }
}
