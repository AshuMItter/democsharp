﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source =.; Initial Catalog = TempDB;Integrated Security = true");
            con.Open();
            //  SqlCommand com = new SqlCommand("Select * from ForSQL1", con);

            SqlDataAdapter sda = new SqlDataAdapter("Select * from ForSQL1", con);

            DataSet ds = new DataSet();
            sda.Fill(ds, "ForSQL1");

            dataGridView1.DataSource = ds.Tables[0];

            DataTable dt = ds.Tables[0];

            DataRow dr = dt.Rows[3];
            foreach (var item in dr.ItemArray)
            {
                Console.WriteLine(item);
            }

            DataColumn dc = dt.Columns[0];

            Console.WriteLine(dc.Caption);
            //Console.WriteLine(dt.);

            con.Close();
            con.Dispose();
        }
    }
}
