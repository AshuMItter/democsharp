﻿using System;
using CSharpNewFeatures.CSharpTwoPointZero;
using CSharpNewFeatures.CSharpThreePointZero;
using CSharpNewFeatures.CsharpFourPointZero;
using System.Collections.Generic;
using System.Linq;
using CSharpNewFeatures.cSharpSixPointZero;
using System.Threading;
using System.Threading.Tasks;
using CSharpNewFeatures.CSharpEightPointZero;
using CSharpNewFeatures.CSharpEightPointZero;
using CSharpNewFeatures.CSHarpNinePointZeo;
using CSharpNewFeatures.CSharpSevenPoointZero;

namespace CSharpNewFeatures
{
    class Program
    {
        
        public static async  void Method()
        {
          await Task.Run(new Action(LongTask));
          Console.WriteLine("New Thread");
        }
        public static void LongTask()
        {
           
            Thread.Sleep(20);
            Console.WriteLine("Hello World");

        }
     
        static void Main(string[] args)
        {
            Method();


            //RecordDemo demo = new RecordDemo();
            //demo.RecordUpdate();

            //Console.WriteLine("Hello World");


            //IndicesAndRangeOperator.Demo();

            //Person p = new Person();
            //if(p.Name is null)
            //{
            //    Console.WriteLine("yes it is ");
            //}
            //else
            //{
            //    Console.WriteLine("No it is not");
            //}




            //if (obj is Program)
            //{
            //    Console.WriteLine("Yes it is.");
            //}
            //else
            //{
            //    Console.WriteLine("No it is not.");
            //}

            //Console.WriteLine("Hi  "+value+"  ! Hope you enjoying in    "+location);

            //Console.WriteLine($"|{"Left",7}|{"Right",7}|");
            //List<Person> list = new List<Person>()
            //{
            //    new Person(){ Age=34, Name="Joe"},
            //    new Person(){ Age=35, Name="Neo"},
            //    new Person(){ Age=36, Name="Ritu"},
            //    new Person(){ Age=37, Name="Kalpana"},

            //};

            //foreach (var item in list)
            //{
            //    Console.WriteLine($"{item.Name, -5} is");
            //    Console.WriteLine($"{ item.Age,5} years old.");
            //}

            //Method();
            //Console.WriteLine("Main thread");
            //Console.ReadLine();


            // List<Cat> catMando = new List<Cat>()
            // {
            // new Cat(){ Age=2, Name="CatMandoONe"},
            // new Cat() { Age = 3, Name = "CatMandoTwo" },
            // new Cat() { Age = 4, Name = "CatMandoThree" },
            // new Cat() { Age = 6, Name = "CatMandoFour" },
            // new Cat() { Age = 7, Name = "CatMandoFive" },
            // new Cat() { Age = 9, Name = "CatMandoSix" },
            // new Cat() { Age = 10, Name = "CatMandoSeven" },
            // new Cat() { Age = 11, Name = "CatMandoEight" },
            // new Cat() { Age = 12, Name = "CatMandoNine" },
            //  new Cat() { Age = 13, Name = "CatMandoTen" },
            // };

            //// Console.WriteLine(catMando.Count);




            // var result = from data in catMando
            //              where data.Age > 4 && data .Age <10
            //              select data;


            // foreach (var item in result)
            // {
            //     Console.WriteLine(item.Name);
            // }

            // Anonymousmethods obj = new Anonymousmethods();
            //obj.AnonymousMethodDemo();

            //Console.WriteLine("Hello World!");

            //LoopingDays days = new LoopingDays();
            //foreach (var item in days)
            //{
            //    Console.WriteLine(item);
            //}

            //PartialMethods part = new PartialMethods();
            //part.Demo();

            //string a = "HelloWorl,All?NewTown";

            //DemoAdd verMath = new DemoAdd();

            //Console.WriteLine(verMath.Multiply(23, 56));

            //DynamicBinding binDing = new DynamicBinding();
            //binDing.Demo();




        }
    }
}
