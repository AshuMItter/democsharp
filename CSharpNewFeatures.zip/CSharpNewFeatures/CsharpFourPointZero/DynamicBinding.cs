﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CsharpFourPointZero
{
    class DynamicBinding
    {
        public void Demo()
        {
            dynamic text = "Demo-one";

            Console.WriteLine(text.Length);
            Console.WriteLine(text.Month);
        }
    }
}
