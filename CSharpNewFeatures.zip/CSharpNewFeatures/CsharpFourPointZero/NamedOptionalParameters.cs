﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CsharpFourPointZero
{
    class NamedOptionalParameters
    {
        public void SimpleMethod(int age, string name, bool isOk)
        {

        }
        public void OptionalParamsMethod(int age=0, string name="default", bool isOk=false)
        {

        }
        public void OldWay()
        {
            SimpleMethod(23,"Ashu", false);
        }
        public void NamedParamtersMethodCall()
        {
            SimpleMethod(name: "Jeetu", isOk: true, age: 23);
        }
        public void OptionaParamtersMethodCall()
        {
            OptionalParamsMethod(23,"Ashu");
        }
    }
}
