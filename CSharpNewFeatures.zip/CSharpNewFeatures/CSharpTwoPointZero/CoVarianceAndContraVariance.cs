﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CSharpTwoPointZero
{
    //covariance and contravariance
    //enable implicit reference conversion
    //for array types, delegate types,
    //and generic type arguments.

    class CoVarianceAndContraVariance
    {
      
        public void Demo()
        {
            Animal animal = new Dog(); // works well
            animal = new Horse(); // works well

            // not possible without Covariance enabled

            IEnumerable<Animal> lSt = new List<Dog>();

        }   
        
    }
    public class Animal
    {

    }
    public class Dog : Animal
    { }

    public class Horse : Animal
    { }
}
