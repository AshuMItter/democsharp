﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CSharpTwoPointZero
{
    // all are Instances of System.Nullable<T> structure.
   // to represent the undefined value of an underlying value type.
    class NullableValueTypes
    {
        double? pi = 3.14;
        char? letter = 'a';

        int m4 = 10;
       // int? m = m4; -- error

        bool? flag = null;

        // An array of a nullable value type:
        int?[] arr = new int?[10];
        
        public void Demo()
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = null;
            }
            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
        }
    }
}
