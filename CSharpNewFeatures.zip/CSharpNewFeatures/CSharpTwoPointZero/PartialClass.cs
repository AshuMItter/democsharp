﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CSharpTwoPointZero
{
    class PartialClass
    {

    }

   partial class One
    {

    }
   partial class One
    {

    }
    //Generic classes and methods combine reusability, type safety, and efficiency 
    // Declare the generic class.
    public partial class Employee
    {
        public void DoWork()
        {
        }
    }

    public partial class Employee
    {
        public void DoWork(int b)
        {
        }
    }
}
