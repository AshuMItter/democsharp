﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CSharpTwoPointZero
{
    class Anonymousmethods
    {
       public delegate int del(int a);
       public void AnonymousMethodDemo()
       {
            del obj = delegate (int a)
            {
                return a;
            };
            
            Console.WriteLine("From anonymour method :"+obj(23));
       }
        public void GeneralDelegateAssociation()
        {
            del obj = new del(GeneralMethod);
            obj(23);

        }
        public int GeneralMethod(int a)
        {
            Console.WriteLine(a);
            return 1;
        }
        
    }
}
