﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpNewFeatures.CSharpEightPointZero
{
    class IndicesAndRangeOperator
    {
       public static void Demo()
        {
            var words = new string[]
  {
                // index from start    index from end
    "The",      // 0                   ^9
    "quick",    // 1                   ^8
    "brown",    // 2                   ^7
    "fox",      // 3                   ^6
    "jumped",   // 4                   ^5
    "over",     // 5                   ^4
    "the",      // 6                   ^3
    "lazy",     // 7                   ^2
    "dog"       // 8                   ^1
  };
            // indices

            // Console.WriteLine(words[^2]);

            //for (int i = 1; i < 10; i++)
            //{
            //    Console.WriteLine(words[^i]);
            //}

            string[] res = words[1..^2];
            
            foreach (var item in res)
            {
                Console.WriteLine(item);
            }
        }
    }
}
