﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpNewFeatures.CSharpEightPointZero
{
    class DefaultInterfaceMethods
    {
        public static void Demo()
        {
            IDefauttMethod iDm = new Demo();
            iDm.Default();
            
        }
    }
    public class Demo : IDefauttMethod
    {

    }
    interface IDefauttMethod
    {
        void Default()
        {
            Console.WriteLine("I.AM");
        }
    }
}
