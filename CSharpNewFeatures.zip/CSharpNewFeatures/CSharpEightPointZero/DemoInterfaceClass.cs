﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpNewFeatures.CSharpEightPointZero
{
    class DemoInterfaceClass : ITalkToDatabase
    {
        public void Method()
        {
            ITalkToDatabase db = new DemoInterfaceClass();
            db.MethodTwo();
        }

    }
    interface ITalkToDatabase
    {
        void Method();

        void MethodTwo()
        {
            Console.WriteLine("I.AM is now U.And.I");
        }
       
        void DefaultMethods()
        {
            Console.WriteLine("I.AM");
        }
    }
}
