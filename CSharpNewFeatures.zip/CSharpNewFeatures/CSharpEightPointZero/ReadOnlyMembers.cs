﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpNewFeatures.CSharpEightPointZero
{
    class ReadOnlyMembers
    {
        public readonly double pi = 22 / 7;
        public const double data = 22 / 7;

        //public const double goldenRatio;
        public ReadOnlyMembers(double val)
        {
            pi = val;   
        }
        public  void Demo()
        {
           
            Console.WriteLine();
        }
    }
    class Age
    {
        private readonly int _year;
        Age(int year)
        {
            _year = year;
        }
        void ChangeYear()
        {
            //_year = 1967; // Compile error if uncommented.
        }
    }
}
