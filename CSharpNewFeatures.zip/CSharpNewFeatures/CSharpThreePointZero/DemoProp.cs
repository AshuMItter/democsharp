﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CSharpThreePointZero
{
    class DemoProp
    {
        int age = 45;

        public int Age
        {
            get { return age; }
            set { age = value; }

        }
    }
}
