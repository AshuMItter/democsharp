﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CSharpThreePointZero
{
   partial class PartialMethods
    {
   partial void MethodOne(string s);

   partial void MethodOne(string s)
   {
            Console.WriteLine("Hello World");
   }
   

    }
  partial class PartialMethods
    {

        

        public void Demo()
        {
            MethodOne("ashu");
        }
       

    }
    partial class PartialMethods
    {
        
    }
}
