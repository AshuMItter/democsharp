﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CSharpThreePointZero
{
    class AnonymousTypes
    {
     
        public void Demo()
        {
           

            

        }
    }
}
