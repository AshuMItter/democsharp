﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CSharpThreePointZero
{
   public class DemoAdd
    {
        public int num1 { get; set; }
        public int num2 { get; set; }
        public void Add(int a, int b)
        {

        }
        public void Update(int a, int b)
        {

        }
        public void Delete(int a, int b)
        {

        }
    }
}
