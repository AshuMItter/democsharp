﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CSharpThreePointZero
{
    class ImplicitlyTypedLocalVariables
    {
        public void Demo()
        {
            var value = "string";

            var iImp = 10; // Implicitly typed.

            int iExp = 10; // Explicitly typed.
        }
    }
}
