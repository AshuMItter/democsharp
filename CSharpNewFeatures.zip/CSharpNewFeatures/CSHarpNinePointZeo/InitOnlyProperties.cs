﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpNewFeatures.CSHarpNinePointZeo
{
    class InitOnlyProperties
    {
        public int X { get; init; } = 56;
        public int Y { get; init; } = 67;

        public InitOnlyProperties(int v)
        {
            Y = v;
        }
        public void Demo()
        {

            Console.WriteLine(Y);
        }
    }
    
}
