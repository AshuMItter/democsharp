﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpNewFeatures.CSHarpNinePointZeo
{
    class LocalFunctionAttributes
    {
        public static void Demo()
        {
           [Obsolete("Dont use it", true)]        
           static void LocalFuntion()
            {
                Console.WriteLine("Local Function");
                   // return 34;
                
            }
            
        }
    }
}
