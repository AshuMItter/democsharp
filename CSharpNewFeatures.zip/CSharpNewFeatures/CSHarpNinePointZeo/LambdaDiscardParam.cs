﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpNewFeatures.CSHarpNinePointZeo
{
    class LambdaDiscardParam
    {
        public delegate void Del(int a, int b);
        public void Demo()
        {
            Del del = (_, _) => { Console.WriteLine("Plain statements"); };
            del(30,30);
        }
    }
}
