﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebApplication17ModelValidations.Models;

namespace WebApplication17ModelValidations.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        [ViewData]
        public string Name { get; set; }

        public IActionResult SaveData(ModelClass model)
        {
           
            var flag = false;
            //if (ModelState.IsValid)
            //{
            //    return RedirectToAction("Index");
            //}
            return View();
        }

       [AcceptVerbs("GET","POST")]
       public IActionResult Validate(string Email)
        {
            List<string> emails = new List<string>() { "ashu@gmail.com" };
            if (emails.FirstOrDefault(x => x == Email) == null) {
                return Json(false);
            
            }
            else
            {
                return Json(true);
            }

            
        }
        public IActionResult Index()
        {
            var mod = new ModelClass()
            {
                Name = "Ashu",
                Age = 45,
                Continets = new List<string>() { "Asia", "Aafrica", "Europe", "Antarctica", "South America" }

            };
           
            return View(mod);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
