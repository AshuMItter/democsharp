﻿
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.Linq;

namespace WebApplication17ModelValidations.Models
{
    public class ModelClass
    {
       
        [Required]
        public string Name { get; set; }

        public void Demo()
        {
            List<ModelClass> val = new List<ModelClass>();
            var value = new ModelClass()
            {
                Age = 34,
                Gender = "Male"
            };

            var res = val.FirstOrDefault(x => x.Age == 34);
        }
        [Range(1,100,ErrorMessage ="Plase check the age ")]
        public int Age { get; set; }


        public bool isOk { get; set; }

        public List<string> Continets { get; set; }

        public string Gender { get; set; }

        [Required]
        [Remote(action: "Validate", controller: "Home")]
        public string Email { get; set; }

        [Url(ErrorMessage ="Its not a Url")]
        public string Url { get; set; }


        [Phone(ErrorMessage ="Please check the number")]
        public int Phone { get; set; }


        [Compare("Age")]
        public int AgeToMatch { get; set; }


        [StringLength(30)]
        public string Address { get; set; }


       // [Remote(action:"Validate",controller:"Home", ErrorMessage ="Not in the Database.")]
        public string YourName { get; set; }
    }
}
