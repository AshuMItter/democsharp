﻿using System;
using EntityFramework.Models;
using System.Linq;
namespace EntityFramework
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            //TemDBContext ctx = new TemDBContext();
            //QueryingTheData.FetchData();

            //IUC obj = new IUC();
            //obj.AddData();
            var cntx = new TemDBContext();
            var res = from data in cntx.IdentityDemos
                      where data.ProductId > 3
                      select data;

            IUC obj = new IUC();
            obj.AddData();
                      
         








        }

    }
  public  class MyClass
    {
        public int ID { get; set; }
        public int Age { get; set; }
        public string Name { get; set; }
    }
}
