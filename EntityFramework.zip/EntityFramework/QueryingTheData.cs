﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityFramework.Models;
namespace EntityFramework
{
    class QueryingTheData
    {
        public static void FetchData()
        {
            var cntx = new TemDBContext();

            var res = from val in cntx.IdentityDemos
                      where val.ProductId < 12
                      select val;

            foreach (var item in res)
            {
                Console.WriteLine(item.ProductName);
            }

           
        }
    }
}
