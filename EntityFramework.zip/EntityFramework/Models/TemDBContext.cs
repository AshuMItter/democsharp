﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace EntityFramework.Models
{
    public partial class TemDBContext : DbContext
    {
        public TemDBContext()
        {

        }

        public TemDBContext(DbContextOptions<TemDBContext> options)
            : base(options)
        {

        }

        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<DemoOne> DemoOnes { get; set; }
        public virtual DbSet<DemoView> DemoViews { get; set; }
        public virtual DbSet<IdentityDemo> IdentityDemos { get; set; }
        public virtual DbSet<IdentityDemo1> IdentityDemo1s { get; set; }
        public virtual DbSet<NewTable> NewTables { get; set; }
        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<Person> Persons { get; set; }
        public virtual DbSet<TableForTran> TableForTrans { get; set; }
        public virtual DbSet<TemTable> TemTables { get; set; }
        public virtual DbSet<TemTable2> TemTable2s { get; set; }
        public virtual DbSet<V5> V5s { get; set; }
        public virtual DbSet<ViewA> ViewAs { get; set; }
        public virtual DbSet<Vv1> Vv1s { get; set; }
        public virtual DbSet<Vv2> Vv2s { get; set; }
        public virtual DbSet<Vv3> Vv3s { get; set; }
        public virtual DbSet<Vv4> Vv4s { get; set; }

       // public DbSet<Class> classes { get; set; }


        //public virtual DbSet<staff> staff { get; set; }
        //public virtual DbSet<MyClass> myclass { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=.;Database=TemDB;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Customer");

                entity.Property(e => e.Email)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("first_name");

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("last_name");

                entity.Property(e => e.Phone)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("phone");
            });

            modelBuilder.Entity<DemoOne>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("DemoOne");

                entity.Property(e => e.Alpha)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DemoView>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("DemoView");

                entity.Property(e => e.Alpha)
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<IdentityDemo>(entity =>
            {
                entity.HasKey(e => e.ProductId)
                    .HasName("PK__Identity__B40CC6ED8B93926D");

                entity.ToTable("IdentityDemo");

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<IdentityDemo1>(entity =>
            {
                entity.HasKey(e => e.ProductId)
                    .HasName("PK__Identity__B40CC6EDF14AA26E");

                entity.ToTable("IdentityDemo1");

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<NewTable>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("NewTable");

                entity.Property(e => e.Alpha)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Order>(entity =>
            {
                entity.Property(e => e.OrderId)
                    .ValueGeneratedNever()
                    .HasColumnName("OrderID");

                entity.Property(e => e.PersonId).HasColumnName("PersonID");

                entity.HasOne(d => d.Person)
                    .WithMany(p => p.Orders)
                    .HasForeignKey(d => d.PersonId)
                    .HasConstraintName("FK__Orders__PersonID__66603565");
            });

            modelBuilder.Entity<Person>(entity =>
            {
                entity.Property(e => e.PersonId)
                    .ValueGeneratedNever()
                    .HasColumnName("PersonID");

                entity.Property(e => e.LocationWhere)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.NameofThePerson)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TableForTran>(entity =>
            {
                entity.HasKey(e => e.ProductId)
                    .HasName("PK__TableFor__B40CC6ED6CDECA82");

                entity.Property(e => e.ProductId)
                    .ValueGeneratedNever()
                    .HasColumnName("ProductID");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TemTable>(entity =>
            {
                entity.HasKey(e => e.ProductId)
                    .HasName("PK__TemTable__B40CC6ED1A907C93");

                entity.ToTable("TemTable");

                entity.Property(e => e.ProductId)
                    .ValueGeneratedNever()
                    .HasColumnName("ProductID");

                entity.Property(e => e.Alpha)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ProductName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TemTable2>(entity =>
            {
                entity.HasKey(e => e.ProductId)
                    .HasName("PK__TemTable__B40CC6ED12C0CE36");

                entity.ToTable("TemTable2");

                entity.Property(e => e.ProductId)
                    .ValueGeneratedNever()
                    .HasColumnName("ProductID");

                entity.Property(e => e.NameIt)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<V5>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("V5");

                entity.Property(e => e.NameIt)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProductName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ViewA>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("ViewA");

                entity.Property(e => e.Alpha)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Vv1>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Vv1");

                entity.Property(e => e.Alpha)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Vv2>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Vv2");

                entity.Property(e => e.Alpha)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Vv3>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Vv3");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Vv4>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Vv4");

                entity.Property(e => e.NameIt)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProductName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<staff>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Staff");

                entity.Property(e => e.Email)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("first_name");

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("last_name");

                entity.Property(e => e.Phone)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("phone");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
