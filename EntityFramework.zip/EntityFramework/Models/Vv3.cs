﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EntityFramework.Models
{
    public partial class Vv3
    {
        public string ProductName { get; set; }
    }
}
