﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EntityFramework.Models
{
    public partial class TemTable2
    {
        public int ProductId { get; set; }
        public string NameIt { get; set; }
        public int? Price { get; set; }
    }
}
