﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EntityFramework.Models
{
    public partial class ViewA
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int? Price { get; set; }
        public long? Quantity { get; set; }
        public string Alpha { get; set; }
    }
}
