﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EntityFramework.Models
{
    public partial class Vv4
    {
        public string ProductName { get; set; }
        public string NameIt { get; set; }
    }
}
