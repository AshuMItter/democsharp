﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityFramework.Models;
namespace EntityFramework
{
    class IUC
    {
        public void AddData()
        {
            var ctx = new TemDBContext();
            IdentityDemo dmo1 = new IdentityDemo();
            dmo1.ProductName = "Laptop1";
            IdentityDemo dmo2 = new IdentityDemo();
            dmo2.ProductName = "Laptop2";
            IdentityDemo dmo3 = new IdentityDemo();
            dmo3.ProductName = "Laptop3";

            ctx.IdentityDemos.Add(dmo1);
            ctx.IdentityDemos.Add(dmo2);
            ctx.IdentityDemos.Add(dmo3);

            Console.WriteLine(ctx.SaveChanges());
            
        }
        public void UpdateData()
        {
            var ctx = new TemDBContext();
            var data = ctx.IdentityDemos.First(x => x.ProductId == 1);

            data.ProductName = "Hummer";

            ctx.SaveChanges();

        }

        public void RemoveData()
        {
            var ctx = new TemDBContext();
            var data = ctx.IdentityDemos.First(x => x.ProductId == 1);

            ctx.IdentityDemos.Remove(data);

            ctx.SaveChanges();
        }


    }
}
