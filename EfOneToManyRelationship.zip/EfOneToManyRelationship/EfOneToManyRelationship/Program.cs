﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore.SqlServer;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using System.Linq;
namespace EfOneToManyRelationship
{
    class Program
    {
        static void Main(string[] args)
        {


            MyContext db = new MyContext();
            Teacher teacher = new Teacher() { TeacherName = "Asha" };
           // db.teachers.Add(teacher);

            Student std = new Student() { StudentName = "Pradeep", TeacherID = 1 };
            //db.students.Add(std);
            //Console.WriteLine(db.SaveChanges());

           Teacher t1= db.teachers.FirstOrDefault(x => x.TeacherID == 1);

            db.teachers.Remove(t1);

            Console.WriteLine(db.SaveChanges());


         
          
        }
    }


    public class MyContext: DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=.;Database=NewDataBase;Trusted_Connection=True;");

        }

        public DbSet<Student> students { get; set; }
        public DbSet<Teacher> teachers { get; set; }

       

    }
    // many users are managing ApplePhone
    public class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }

        //Foreign key for Standard
        public int TeacherID { get; set; }
        public Teacher Teacher { get; set; }

        
    }

    public class Teacher
    {
        public int TeacherID { get; set; }
        public string TeacherName { get; set; }

        // Primary Key Table
        public ICollection<Student> Students { get; set; }

       

    }
}
