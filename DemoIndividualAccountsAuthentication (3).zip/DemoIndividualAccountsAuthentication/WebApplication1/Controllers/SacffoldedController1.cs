﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication1.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class ScaffoldedController : ControllerBase
    {
        // GET: api/<ValuesController1>
       // [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<ValuesController1>/5
       // [HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        // POST api/<ValuesController1>
       // [HttpPost]
        public IActionResult Post([FromBody] Data value)
        {
           
           return Ok(value);
        }

        // PUT api/<ValuesController1>/5
       // [HttpPut("{id}")]
        public void Put(int id, [FromBody] object value)
        {
        }

        // DELETE api/<ValuesController1>/5
       // [HttpDelete("{id}")]
        public IActionResult Delete()
        {
            return Ok();
        }
    }
}
