﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Controllers
{
   
    [ApiController]
    [Route("[controller]")]
    [Route("employee")] // base route 
    public class ValuesController : ControllerBase
    {
        [Route("Emp/All")]
        public string GetAllEmployees()
        {
            return "Response from GetAllEmployees Method";
        }
        [Route("Emp")]
        public string GetEmployeeById(int id)
        {
            return "Response from GetEmployeeById Method :"+ id;
        }


        [Route("Emp/Mul")]
        public string GetEmployeeData(int age, string name)
        {
            return $"Response from GetEmployeeData - Your age is: {age} and name is {name}";
        }


        [Route("Emp/Mul/2")]
        [Route("Emp/Mul/Demo")]
        [Route("Emp/Mul/Demo/Abc")]
        public string GetEmployeeData(int age)
        {
            return age + "";
        }


       public IActionResult Post()
        {
            return Ok();
        }
    }
}
