﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Linq;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        List<Data> lIst = new List<Data>()
        {
            new Data()
            {
                 Age=34,
                  Location="Lohgaon",
                   Name="Joe"
            },
            new Data()
            {
                 Age=20,
                  Location="London",
                   Name="Smith"
            },
            new Data()
            {
                 Age=50,
                  Location="Russia",
                   Name="Mary"
            },
            new Data()
            {
                 Age=20,
                  Location="USA",
                   Name="Rohan"
            },
            new Data()
            {
                 Age=15,
                  Location="California",
                   Name="Preet"
            },
        };
        [HttpGet]
        [Route("names/{age}")]
        public Data GetData(int age)
        {
            return lIst.FirstOrDefault(x => x.Age == age);
        }

        [HttpPost]
        [Route("postnames")]
        public int PostTheData([FromBody] Data data)
        {
            lIst.Add(data);
            return lIst.Count;
        }

        [HttpPut]
        [Route("updatedata/{age}")]
        public IActionResult UpdateData(int age, [FromBody] Data data)
        {
            Data newdata = lIst.FirstOrDefault(x => x.Age == age);
            if (newdata != null)
            {
                lIst.Remove(newdata);
                lIst.Add(data);
                return Ok(lIst);

            }
            else
            {
                return BadRequest();
            }

        }


       // [HttpGet]      
       // public IActionResult Get()
       // {


       //     var rng = new Random();
       //   var res =  Enumerable.Range(1, 5).Select(index => new WeatherForecast
       //     {
       //         Date = DateTime.Now.AddDays(index),
       //         TemperatureC = rng.Next(-20, 55),
       //         Summary = Summaries[rng.Next(Summaries.Length)]
       //     })
       //     .ToArray();

       //     if(res.Length  > 0)
       //     {
       //         return Ok(res);
       //     }
       //     else
       //     {
       //         return BadRequest();
       //     }
       // }

       // [Route("name")] //domainname/controllername/name
       // [Route("name/yourname")]
       // [Route("data/yourname/myname")]
       // [Route("data/yourname/myname/thiername")]
       // public string GetName()
       // {
       //     return "Joe";
       // }

       // [Route("data")] //domaninname/controllernanem/data

       // public IActionResult GetData()
       // {
       //    var res=  new Data()
       //     {
       //         Age = 34,
       //         Name = "Ashu"

       //     };
       //     return Conflict();
       // }


       //[HttpPost]
       //[Route("postman")]
       // public IActionResult Post([FromBody] Data data)
       // {
       //     return Ok(data);
       // }
        
       // //[HttpPut]
       // //[Route("putman")]
       // //public IActionResult Put(int id)
       // //{
       // //    return Ok(id);
       // //}
       // //[HttpDelete]
       // //[Route("deleteman")]
       // //public IActionResult Delete(int id)
       // //{
       // //    return Ok(id);
       // //}
       // [Route("one/{id}")] //domainname/controllername/one/1
       // public IActionResult MyCutomizedMethod(int id)
       // {
       //     return Ok(id);
       // }

       // [Route("two")] //domainname/controllername/two?id=1
       // public string DemoMyMethod(int id,string name)
       // {
       //     return id + name;
       // }

       // public IActionResult DemoReturnType()
       // {
       //     return Ok();
       // }


       // [HttpPut]
       // [Route("putman")]  // WeatherForecast/putman
       // public string Update()
       // {
       //     return "Http - Put is called...";
       // }

       // [HttpDelete]
       // [Route("deleteman")]
       // public string DeleteTheData()
       // {
       //     return "http - delete is called...";
       // }


    }
    public class Data
    {
        public int Age { get; set; }
        public string Name { get; set; }

        public string Location { get; set; }
    }
}
