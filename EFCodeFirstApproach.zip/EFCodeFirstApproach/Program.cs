﻿using Microsoft.EntityFrameworkCore;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EFCodeFirstApproach
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            var ctx = new MyDebContext();
            AppleIPad data = new AppleIPad() {IsInStock = true, Price = 85000, ScreenSize = 345.67f };
            ctx.appleipads.Add(data);

            string strPc = "Proc_Procedure2";

            var res = ctx.appleipads.FromSqlRaw<AppleIPad>("P_Proc2");

            foreach (var item in res)
            {
                Console.WriteLine(item.ScreenSize);
            }

           // Console.WriteLine(ctx.SaveChanges());


        }
    }


    class MyDebContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server =.; Database = AngularReact; Trusted_Connection = True; ");
        }

        public DbSet<IPhone> iphones { get; set; }

        public DbSet<AirPod> airpods { get; set; }

        public DbSet<AppleIPad> appleipads { get; set; }
        
        public DbSet<AppleIWatch> appleiwatches { get; set; }

        public DbSet<PKClass> pkclasses { get; set; }

        public DbSet<FKClass> fkclasses { get; set; }
    }

    class IPhone
    {
        public int IPhoneID { get; set; }

        public string Version { get; set; }

        public decimal Price { get; set; }

        public float ScreenSize { get; set; }
    }

    public class AirPod
    {
        [Key]
        public int PodID { get; set; }

        public string Name { get; set; }

        public string Color { get; set; }

        public decimal Price { get; set; }
    }

    [Table("SomethingElse_AppleiPad")]
    public class AppleIPad
    {
        [Column("AppleIpadIdentity")]
        [Key]
        public int AppleIdentity { get; set; }

       

        public string Version { get; set; }

        [Required()]
        public decimal Price { get; set; }

        public float ScreenSize { get; set; }

        public bool IsInStock { get; set; }
    }

    public class AppleIWatch
    {
        [Key]
      public int  IWatchID { get; set; }


        public decimal Price { get; set; }

        public float ScreenSize { get; set; }

        public bool IsInStock { get; set; }
    }



    public class PKClass
    {
        public int PKClassID { get; set; }
        public string Name { get; set; }

        public FKClass RelationValues { get; set; }
    }

    public class FKClass
    {
        public int FKClassID { get; set; }

        public string NameInFkClass { get; set; }
    }
}
