﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EFCodeFirstApproach.Migrations
{
    public partial class ValueMig : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "fkclasses",
                columns: table => new
                {
                    FKClassID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NameInFkClass = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_fkclasses", x => x.FKClassID);
                });

            migrationBuilder.CreateTable(
                name: "pkclasses",
                columns: table => new
                {
                    PKClassID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RelationValuesFKClassID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pkclasses", x => x.PKClassID);
                    table.ForeignKey(
                        name: "FK_pkclasses_fkclasses_RelationValuesFKClassID",
                        column: x => x.RelationValuesFKClassID,
                        principalTable: "fkclasses",
                        principalColumn: "FKClassID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_pkclasses_RelationValuesFKClassID",
                table: "pkclasses",
                column: "RelationValuesFKClassID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "pkclasses");

            migrationBuilder.DropTable(
                name: "fkclasses");
        }
    }
}
