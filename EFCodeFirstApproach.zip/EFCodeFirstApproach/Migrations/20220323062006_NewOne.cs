﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EFCodeFirstApproach.Migrations
{
    public partial class NewOne : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "airpods",
                columns: table => new
                {
                    PodID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Color = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_airpods", x => x.PodID);
                });

            migrationBuilder.CreateTable(
                name: "appleiwatches",
                columns: table => new
                {
                    IWatchID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    ScreenSize = table.Column<float>(type: "real", nullable: false),
                    IsInStock = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_appleiwatches", x => x.IWatchID);
                });

            migrationBuilder.CreateTable(
                name: "SomethingElse_AppleiPad",
                columns: table => new
                {
                    AppleIpadIdentity = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Version = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    ScreenSize = table.Column<float>(type: "real", nullable: false),
                    IsInStock = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SomethingElse_AppleiPad", x => x.AppleIpadIdentity);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "airpods");

            migrationBuilder.DropTable(
                name: "appleiwatches");

            migrationBuilder.DropTable(
                name: "SomethingElse_AppleiPad");
        }
    }
}
