import { useSelector, useDispatch } from 'react-redux';
import {increment, decrement, setName} from './counterSlice';
export default function Demo(){



const count = useSelector((state) => state.counter.value);
  const nameVal = useSelector((state) => state.counter.name);
  const dispatch = useDispatch()

  function callDisp(){

    dispatch(increment());
  }
  function setNameVal(){
    dispatch(setName("New One"));
  }

  return (
    <>
    <button onClick={callDisp}>
      ++
    </button>
   <p> {count}</p>
   <button onClick={setNameVal}>
     Set Name
   </button>
   <p>{nameVal}</p>
    </>
  );
}
