
import {useState, useRef, useEffect} from 'react';
import $ from 'jquery';
export default function Form(){

    const [summary,setSummary] = useState("");
    const [tempC,setTempC] = useState("");
    const [tempf,setTempF] = useState("");
    const [date,setDate] = useState("");
    
    useEffect(()=>{

    })
     function UpdateData(){
        var res ={
            date: date,
            summary:summary,
            temperatureF:parseInt(tempf),
            temperatureC:parseInt(tempC)

        }
        $.ajax({
            type:'Put',
            url: "https://localhost:44344/weatherforecast/update/"+tempC, 
           
            contentType: "application/json",
            data:JSON.stringify(res),
        success: function(result) {
                 alert(result);
                }});
     }
    function PostData(){

        var res ={
            date: date,
            summary:summary,
            temperatureF:parseInt(tempf),
            temperatureC:parseInt(tempC)

        }
        $.ajax({
            type:'Post',
            url: "https://localhost:44344/weatherforecast/save", 
           
            contentType: "application/json",
            data:JSON.stringify(res),
        success: function(result) {
                 alert(result);
                }});
      //$.post("https://localhost:44344/weatherforecast/save",res,function(data){alert(data)},"application/json");
    }
    function setSum(e){
      setSummary(e.target.value);
    }
    function setTemC(e){
     setTempC(e.target.value);
    }
    function setTemF(e){
    setTempF(e.target.value);
    }
    function setDte(e){
        var dte = new Date();
        dte = e.target.value;
        alert(dte);
     //alert();
    setDate(dte);
    }

    return(
        <>
        <input type="text" onChange={setSum}/>
        <input type="text" onChange={setTemC}/>
        <input type="text" onChange={setTemF} />
        <input type="date" onChange={setDte} />
        <button onClick={PostData}> Add </button>
        <button onClick={UpdateData}>Update</button>
        </>
    )
}