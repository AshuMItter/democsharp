import logo from './logo.svg';
import './bootstrap.min.css';
import Form from './form.component';
import Timer from './counter.component';

function App() {
  return (
    <>
    <Form />
    <Timer />
    </>
  );
}

export default App;
