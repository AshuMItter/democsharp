import logo from './logo.svg';
import './App.css';
import { useSelector, useDispatch } from 'react-redux';
import {increment, decrement, setName} from './counterSlice';
import Demo from './demo.component';


function App() {
  const count = useSelector((state) => state.counter.value);
  const nameVal = useSelector((state) => state.counter.name);
  const dispatch = useDispatch()

  function callDisp(){
    dispatch(increment());
  }
  function setNameVal(){
    dispatch(setName("Ashu"));
  }

  return (
    <>
    {/* <button onClick={callDisp}>
      ++
    </button>
   <p> {count}</p>
   <button onClick={setNameVal}>
     Set Name
   </button>
   <p>{nameVal}</p> */}
   <Demo />
    </>
  );
}

export default App;
