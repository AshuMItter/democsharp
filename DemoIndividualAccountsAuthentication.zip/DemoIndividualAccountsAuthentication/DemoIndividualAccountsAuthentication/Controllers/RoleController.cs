﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoIndividualAccountsAuthentication.Controllers
{
    public class RoleController : Controller
    {
        RoleManager<IdentityRole> manager;


        public RoleController(RoleManager<IdentityRole> manager)
        {
            this.manager = manager;
        }
        public IActionResult Index()
        {
            var roles = manager.Roles.ToList();
            return View(roles);
        }

        public IActionResult Create()
        {
            return View(new IdentityRole());
        }
    }
}
